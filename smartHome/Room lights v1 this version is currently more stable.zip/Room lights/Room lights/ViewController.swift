//
//  ViewController.swift
//  Room lights
//
//  Created by Ferdinand Lösch on 14/03/2017.
//  Copyright © 2017 Ferdinand Lösch. All rights reserved.
//

import UIKit
import Canvas
import Alamofire



class ViewController: UIViewController {

    @IBOutlet weak var lit: UIImageView!
    
    @IBOutlet weak var ani: CSAnimationView!
    
    @IBOutlet weak var spniner: UIActivityIndicatorView!
    @IBOutlet weak var label: UILabel!
    var isON = Bool()
    var timer = Timer()
    var timer2 = Timer()
    // ferdinand
    
    let urlON = "http://172.20.103.211/on"
    let urlOFF = "http://172.20.103.211/off"
    // Matthew
//    let urlON = URL(string: "http://172.20.104.200/on")
//    let urlOFF = URL(string: "http://172.20.104.200/off")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        label.text = "set State"
        spniner.startAnimating()
        lightsCenatet()
        buttonOut.isEnabled = false
        askForNotifications()
        timer = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(ViewController.lightsCenatet), userInfo: nil, repeats: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var buttonOut: UIButton!
    
    @IBAction func on(_ sender: Any) {
        if isON {
    
            Alamofire.request(urlON).response { response in
                if response.error != nil {
                    self.alertTheUser(title: "A error has occurred", message: "the connection to your light cannot be established 😟")
                }
            
            }
            label.text = "ON"
            buttonOut.isEnabled = false
            animatorON()
            isON = false
            timer = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(ViewController.enableButtonFunc), userInfo: nil, repeats: false)
        
            
        } else {
            
            Alamofire.request(urlOFF).response { response in
                if response.error != nil {
                    self.alertTheUser(title: "A error has occurred", message: "the connection to your light cannot be established 😟")
                }
            }
            label.text = "OFF"
            buttonOut.isEnabled = false
            animatorOFF()
            isON = true
            timer = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(ViewController.enableButtonFunc), userInfo: nil, repeats: false)
            
      }
    }
    
    func enableButtonFunc(){
        buttonOut.isEnabled = true
    }
    
    
    func lightsCenatet() {
        // ferdinand loesch
        Alamofire.request("http://172.20.103.211/index.html").responseJSON { response in
            print(response.request!)  // original URL request
            print(response.data!)     // server data
            print(response.result)// result of response serialization
            
            
            if response.error == nil {
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
                print(String(data: response.data!, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue)) as Any)
                let valus = String(describing: JSON)
                
                if valus == "0" {
                    self.label.text = "OFF"
                    self.spniner.stopAnimating()
                    self.spniner.isHidden = true
                    self.animatorOFF()
                    self.isON = true
                    self.buttonOut.isEnabled = true

                } else {
                    self.label.text = "ON"
                    self.spniner.stopAnimating()
                    self.animatorON()
                    self.isON = false
                    self.spniner.isHidden = true
                    self.buttonOut.isEnabled = true
                }
            }
            } else {
                self.alertTheUser(title: "A error has occurred", message: "the connection to your light cannot be established 😟")
                print("error")
            }
        }
    }
    
     func  alertTheUser(title: String,message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true,completion: nil)
    }

    
    func askForNotifications() {
        NotificationCenter.default.addObserver(self,selector:#selector(ViewController.foreground(notification:)),name:NSNotification.Name.UIApplicationWillEnterForeground,object:nil)
        NotificationCenter.default.addObserver(self,selector:#selector(ViewController.background(notification:)),name:NSNotification.Name.UIApplicationDidEnterBackground,object:nil)
        
        
        }

    
    func foreground(notification:NSNotification) {
        print("foreground")
        timer2 = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(ViewController.lightsCenatet), userInfo: nil, repeats: true)
    
    }
    func background(notification:NSNotification) {
        print("background")
        timer2.invalidate()
        timer.invalidate()
    }

    
    func animatorON(){
        if isON{
            self.ani.delay = 0
            self.ani.duration = 1.5
            self.ani.type = CSAnimationTypePop
            self.ani.startCanvasAnimation()
            self.ani.delay = 0
            self.ani.duration = 0.5
            self.ani.type = CSAnimationTypeFadeIn
            self.ani.startCanvasAnimation()

        }
    }
    func animatorOFF(){
        if !isON {
        self.ani.delay = 0
        self.ani.duration = 2
        self.ani.type = CSAnimationTypeFadeOut
        self.ani.startCanvasAnimation()
        }
    }

}
















