//
//  Constant.swift
//  Room lights
//
//  Created by Ferdinand Lösch on 17/03/2017.
//  Copyright © 2017 Ferdinand Lösch. All rights reserved.
//

import Foundation



struct URLstruct {
    let urlON = "http://172.20.103.211/on"
    let urlOFF = "http://172.20.103.211/off"

}
