//
//  TodayViewController.swift
//  Room light widget
//
//  Created by Ferdinand Lösch on 14/03/2017.
//  Copyright © 2017 Ferdinand Lösch. All rights reserved.
//

import UIKit
import NotificationCenter
import Alamofire


class TodayViewController: UIViewController, NCWidgetProviding {
    
    
    var timer = Timer()
    var timer2 = Timer()
    var isON = false
    let urlON = "http://172.20.103.211/on"
    let urlOFF = "http://172.20.103.211/off"
  
    @IBOutlet weak var spiner: UIActivityIndicatorView!
    @IBOutlet weak var button: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view from its nib.
        button.layer.cornerRadius = 15
        button.layer.opacity = 70
        spiner.isHidden = true
        lightsCenatet()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   

    @IBAction func ButtonAC(_ sender: Any) {
        if !isON {
            
            Alamofire.request(urlOFF).response { response in
                if response.error != nil {
                    self.button.backgroundColor = UIColor.orange
                    self.button.setTitle("Error", for: .normal)
                }
                
            }

            spiner.isHidden = false
            spiner.startAnimating()
            isON = true
            button.backgroundColor = UIColor.red
            button.setTitle("OFF", for: .normal)
            timer2 = Timer.scheduledTimer(timeInterval: (1), target: self, selector: #selector(TodayViewController.spin), userInfo: nil, repeats: false)
            print("mod")
            
            
        } else {
            Alamofire.request(urlON).response { response in
                if response.error != nil {
                    self.button.backgroundColor = UIColor.orange
                    self.button.setTitle("Error", for: .normal)
                    
                }
                
            }
            spiner.isHidden = false
            spiner.startAnimating()
            isON = false
            button.backgroundColor = UIColor.green
            button.setTitle("ON", for: .normal)
            timer2 = Timer.scheduledTimer(timeInterval: (2.2), target: self, selector: #selector(TodayViewController.spin), userInfo: nil, repeats: false)
            print("mod")
            
            
        }
        lightsCenatet()
    }
    
   
    
    func spin(){
        spiner.stopAnimating()
        spiner.isHidden = true
    }
    
    
    
    func lightsCenatet() {
        // ferdinand loesch
        Alamofire.request("http://172.20.103.211/index.html").responseJSON { response in
            print(response.request!)  // original URL request
            print(response.response!) // HTTP URL response
            print(response.data!)     // server data
            print(response.result)// result of response serialization
            
            
            if response.error == nil {
                if let JSON = response.result.value {
                    print("JSON: \(JSON)")
                    print(String(data: response.data!, encoding: String.Encoding(rawValue: String.Encoding.utf8.rawValue)) as Any)
                    let valus = String(describing: JSON)
                    
                    if valus == "0" {
                        self.isON = true
                        self.button.backgroundColor = UIColor.red
                        self.button.setTitle("OFF", for: .normal)
                    } else {
                        self.isON = false
                        self.button.backgroundColor = UIColor.green
                        self.button.setTitle("ON", for: .normal)
                        


                    }
                }
            } else {
               
                self.button.backgroundColor = UIColor.orange
                self.button.setTitle("Error", for: .normal)
            }
        }
    }
    
    

    func widgetPerformUpdate(completionHandler: (@escaping (NCUpdateResult) -> Void)) {
        // Perform any setup necessary in order to update the view.
        
        // If an error is encountered, use NCUpdateResult.Failed
        // If there's no update required, use NCUpdateResult.NoData
        // If there's an update, use NCUpdateResult.NewData
        
        completionHandler(NCUpdateResult.newData)
    }
    
}
