//
//  URLs.swift
//  Room lights
//
//  Created by Ferdinand Lösch on 18/03/2017.
//  Copyright © 2017 Ferdinand Lösch. All rights reserved.
//

import Foundation



struct urlStruct {
    let urlON = "http://172.20.103.211/on"
    let urlOFF = "http://172.20.103.211/off"
    let urlConnect = "http://172.20.103.211/index.html"
    
//    let urlON = "http://172.20.104.200on"
//    let urlOFF = "http://172.20.104.200/off"
//    let urlConnect = "http://172.20.104.200/index.html"

}
