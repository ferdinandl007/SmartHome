//
//  InterfaceController.swift
//  Room lights for watch Extension
//
//  Created by Ferdinand Lösch on 15/03/2017.
//  Copyright © 2017 Ferdinand Lösch. All rights reserved.
//

import WatchKit
import Foundation





class InterfaceController: WKInterfaceController {

    
    
    
    @IBOutlet var but: WKInterfaceButton!
    var isON = true
    var timer = Timer()
    let urlON = URL(string: "http://172.20.104.8/on")
    let urlOFF = URL(string: "http://172.20.104.8/off")
    
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    @IBAction func button() {
        
        if isON {
            
            but.setTitle("ON")
            let task = URLSession.shared.dataTask(with: urlON!) { (data, response, error) in
            }
            
            task.resume()
                        isON = false
                       timer = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(InterfaceController.enableButtonFunc), userInfo: nil, repeats: false)
            
        
            
        } else {
            
            but.setTitle("OFF")
            let task = URLSession.shared.dataTask(with: urlOFF!) { (data, response, error) in
                            }
            
            task.resume()
           
            
            isON = true
        
                        timer = Timer.scheduledTimer(timeInterval: (2), target: self, selector: #selector(InterfaceController.enableButtonFunc), userInfo: nil, repeats: false)
            
        }
    }
    
    func enableButtonFunc()  {
        
    }
    
    
    
  
    
    

    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
